#' Fish growth snippet from Katie's summer 2018 field work
#' @format length is in mm, these are all integers
#' @source Katie Zinn
  "Fish_data"




