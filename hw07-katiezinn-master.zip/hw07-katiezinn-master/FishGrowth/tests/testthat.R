library(testthat)
library(FishGrowth)

test_check("FishGrowth")
