README
================

hw07-katiezinn
==============

hw07-katiezinn created by GitHub Classroom

Welcome to my 7th homework assignment. Please click [here](https://github.com/STAT545-UBC-students/hw07-katiezinn/tree/master/FishGrowth) to view my package that can help you calculate the instantaneous growth of fish

What did I do in this assignment?
---------------------------------

-   I... made a new package!!!
    -   It was absolutely terrifying for me but I hope it was worthwhile so I can get some use out of it during my thesis.
-   Define and export one new function, i.e. make it available to a user upon loading the package.
    -   a function to calculate instantaneous growth of fish
-   Give function arguments sensible defaults, where relevant.
-   Document all exported functions.
-   Include at least three unit tests for your new function that test common use cases that you anticipate of the function.
-   Your package should pass check() without errors (warnings and notes are OK).
-   Update the README and vignette to show usage of all the functions in the package.
-   Modify the instructions telling someone how to install your package.

*I realize that I **only** have one function in my package. You have to realize that creating a new package from scratch is rather time consuming when compared to snagging a package that is already done, so I hope you consider that when analyzing my work*
